package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilbilling.pagebeans.PostpaidAccountBillDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PostpaidAccountAllBillDetailsStepDefinition {
	private WebDriver driver;
	private PostpaidAccountBillDetailsPage page;
	@Given("^User is on Postpaid Account All Bills Page$")
	public void user_is_on_Postpaid_Account_All_Bills_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/postpaidAccountBillDetails");
		page=PageFactory.initElements(driver,PostpaidAccountBillDetailsPage.class);
	}

	@When("^User enters valid Customer ID for retriving all bill details$")
	public void user_enters_valid_Customer_ID_for_retriving_all_bill_details() throws Throwable {
		page.setCustomerID("1001");
	}

	@When("^User enters valid Mobile No and clicks submit button$")
	public void user_enters_valid_Mobile_No_and_clicks_submit_button() throws Throwable {
		page.setMobileNo("9885626398");
		page.clickSubmit();
	}

	@Then("^All bill details are displayed$")
	public void all_bill_details_are_displayed() throws Throwable {
		String expectedTitle = "All Bill Details Page";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User enters invalid Customer ID for retriving all bill details$")
	public void user_enters_invalid_Customer_ID_for_retriving_all_bill_details() throws Throwable {
		page.setCustomerID("9999");
	}

	@Then("^Error message is shown on Postpaid Account All Bills Page$")
	public void error_message_is_shown_on_Postpaid_Account_All_Bills_Page() throws Throwable {
		String expectedError = "Customer not found for Customer ID: " + "9999";
		String actualError = page.getErrorMessage();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}
