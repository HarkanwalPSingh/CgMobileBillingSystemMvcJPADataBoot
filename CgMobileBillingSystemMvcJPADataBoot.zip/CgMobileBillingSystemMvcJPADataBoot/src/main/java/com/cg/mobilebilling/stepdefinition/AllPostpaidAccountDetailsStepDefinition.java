package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilbilling.pagebeans.AllPostpaidAccountDetailsPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllPostpaidAccountDetailsStepDefinition {
	private WebDriver driver;
	private AllPostpaidAccountDetailsPage page;
	@Given("^User is on all postpaid accounts details$")
	public void user_is_on_all_postpaid_accounts_details() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/allPostpaidAccountDetails");
		page=PageFactory.initElements(driver,AllPostpaidAccountDetailsPage.class);
	}

	@When("^User enters correct customer id$")
	public void user_enters_correct_customer_id() throws Throwable {
		page.setCustomerID("1001");
		page.clickSubmit();
	}

	@Then("^display all postpaid account details$")
	public void display_all_postpaid_account_details() throws Throwable {
		String expectedTitle = "All Postpaid Account Details";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^User enters incorrect customer id$")
	public void user_enters_incorrect_customer_id() throws Throwable {
		page.setCustomerID("548");
		page.clickSubmit();
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		String expectedError = "Customer not found for Customer ID: 548";
		String actualError = page.getErrorMessage();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}
