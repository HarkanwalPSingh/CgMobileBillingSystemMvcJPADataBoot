package com.cg.mobilebilling.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.mobilbilling.pagebeans.GenerateBIllPage;
import com.cg.mobilbilling.pagebeans.RemoveCustomerPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GenerateMonthlyBillStepDefinition {
	private WebDriver driver;
	private GenerateBIllPage page;
	@Given("^User is on Generate Bill Page$")
	public void user_is_on_Generate_Bill_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://localhost:4444/generateBill");
		page=PageFactory.initElements(driver,GenerateBIllPage.class);
	}

	@When("^Enters all fields with valid input$")
	public void enters_all_fields_with_valid_input() throws Throwable {
		page.setCustomerID("1001");
		page.setMobileNo("9887762242");//Boot still in <create> mode
		page.setBillMonths("March");
		page.setNoOfLocalSMS("50");
		page.setNoOfStdSMS("50");
		page.setNoOfLocalCalls("50");
		page.setNoOfStdCalls("50");
		page.setInternetDataUsageUnits("100");
	}

	@When("^Clicks genrate bill submit button$")
	public void clicks_genrate_bill_submit_button() throws Throwable {
		page.clickSubmit();
	}

	@Then("^Monthly Bill is generated and displayed on monthly bill page$")
	public void monthly_Bill_is_generated_and_displayed_on_monthly_bill_page() throws Throwable {
		String expectedTitle = "Generate Bill Success Page";
		String actualTitle = driver.getTitle();
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}

	@When("^Enters all fields with invalid input$")
	public void enters_all_fields_with_invalid_input() throws Throwable {
		page.setCustomerID("1001");
		page.setMobileNo("7845654123");
		page.setBillMonths("March");
		page.setNoOfLocalSMS("50");
		page.setNoOfStdSMS("50");
		page.setNoOfLocalCalls("50");
		page.setNoOfStdCalls("50");
		page.setInternetDataUsageUnits("100");
	}

	@Then("^Monthly Bill is not generated and error message is displayed$")
	public void monthly_Bill_is_not_generated_and_error_message_is_displayed() throws Throwable {
		String expectedError = "PostpaidAccount not found for Mobile Number:" + "7845654123";
		String actualError = page.getErrorMessage();
		Assert.assertEquals(expectedError, actualError);
		driver.close();
	}
}
