package com.cg.mobilbilling.pagebeans;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GenerateBIllPage {
	@FindBy(how = How.CLASS_NAME, name = "customerID")
	private WebElement customerID;
	@FindBy(how = How.CLASS_NAME, name = "mobileNo")
	private WebElement mobileNo;
	@FindBy(how = How.CLASS_NAME, name = "billMonth")
	private List<WebElement> billMonths;
	@FindBy(how = How.CLASS_NAME, name = "noOfLocalSMS")
	private WebElement noOfLocalSMS;
	@FindBy(how = How.CLASS_NAME, name = "noOfStdSMS")
	private WebElement noOfStdSMS;
	@FindBy(how = How.CLASS_NAME, name = "noOfLocalCalls")
	private WebElement noOfLocalCalls;
	@FindBy(how = How.CLASS_NAME, name = "noOfStdCalls")
	private WebElement noOfStdCalls;
	@FindBy(how = How.CLASS_NAME, name = "internetDataUsageUnits")
	private WebElement internetDataUsageUnits;
	@FindBy(how = How.CLASS_NAME, name = "submit")
	private WebElement button;
	@FindBy(how = How.ID, id = "error")
	private WebElement errorMessage;

	public void clickSubmit() {
		this.button.click();
	}

	public String getErrorMessage() {
		return this.errorMessage.getText();
	}

	public void setCustomerID(String customerID) {
		this.customerID.sendKeys(customerID);
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}

	public void setBillMonths(String billMonth) {
		for (WebElement billmonth : this.billMonths)
			if (billmonth.getAttribute("value").equals(billMonth))
				billmonth.click();
	}

	public void setNoOfLocalSMS(String noOfLocalSMS) {
		this.noOfLocalSMS.sendKeys(noOfLocalSMS);
	}

	public void setNoOfStdSMS(String noOfStdSMS) {
		this.noOfStdSMS.sendKeys(noOfStdSMS);
	}

	public void setNoOfLocalCalls(String noOfLocalCalls) {
		this.noOfLocalCalls.sendKeys(noOfLocalCalls);
	}

	public void setNoOfStdCalls(String noOfStdCalls) {
		this.noOfStdCalls.sendKeys(noOfStdCalls);
	}

	public void setInternetDataUsageUnits(String internetDataUsageUnits) {
		this.internetDataUsageUnits.sendKeys(internetDataUsageUnits);
	}

}
